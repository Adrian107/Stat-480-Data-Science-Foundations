#!/usr/bin/env python

import re
import sys

for line in sys.stdin:
  val = line.strip()
  (year, temp, q) = (val[15:19], val[87:92], val[92:93])
  if (temp != "-9999" and temp != "+9999" and re.match("[01459]", q)):
    temp = float(temp)
    print "%s\t%s" % (year, (temp/10.0)*1.8+32.0)


