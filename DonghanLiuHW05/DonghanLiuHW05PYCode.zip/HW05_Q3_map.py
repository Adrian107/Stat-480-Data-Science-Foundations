#!/usr/bin/env python

import re
import sys

for line in sys.stdin:
  val = line.strip()
  (year, temp, q, temp1, valid) = (val[15:19], val[87:92], val[92:93], 0, 0)
  if (temp != "+9999" and temp != "-9999"):
    temp1 = 1
  if ( temp != "" and temp != None and re.match("[01459]", q)):
    valid = 1
    print "%s\t%s\t%s" % (year, temp1, valid)

#Quoted from Notes

#Remove space from beginning and end
#Assign each value from the val variable to each variable
#Make sure the temperature locates in the reasonable range
#Ensures the value is valid
#Print out
