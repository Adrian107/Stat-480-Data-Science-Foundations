#!/usr/bin/env python

import sys

(last_key, min_val, max_val, n) = (None, float(sys.maxint), float(-sys.maxint), 0)
print('Year  Minimum Temperature  Maximum Temperature  Observation Number')
for line in sys.stdin:
  (key, val) = line.strip().split("\t")
  if last_key and last_key != key:
    print "%s\t%s\t\t\t%s\t\t\t%s" % (last_key, min_val, max_val, n)
    (last_key, min_val, max_val, n) = (key, float(val), float(val), 1)
  else:
    (last_key, min_val, max_val, n) = (key, min(min_val, float(val)), max(max_val, float(val)), n + 1)
if last_key:
  print "%s\t%s\t\t\t%s\t\t\t%s" % (last_key, min_val, max_val, n)
