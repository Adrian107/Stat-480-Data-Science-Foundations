#!/usr/bin/env python


import sys

(last_key, tempcount, validqcount) = (None, 0, 0)
print('Year  Temp_Count  Valid_Count')
for line in sys.stdin:
  (key, temp1, valid) = line.strip().split("\t")
  if last_key and last_key != key:
    print ("%s\t%s\t\t%s" % (last_key, tempcount, validqcount))
    (last_key, tempcount, validqcount) = (key, int(temp1), int(valid))
  else:
    (last_key, tempcount, validqcount) = (key, int(temp1) + tempcount, int(valid) + validqcount) 

if last_key:
  print ("%s\t%s\t\t%s" % (last_key, tempcount, validqcount))

#Quotes from the Notes
#Initialize tempcount and validcount
#After mapping, take each line from the mapped data
#For each value from mapped data corresponding to key(year), temp1(temperture), and valid(valid number)
#If the previous key is different than this one, then print out
#Else, which is the previsou key is same as this one, then print out with could + int(temp1)
#Then, print out all the counts and years. 
