#Exercise 2
pig -x local -param input=/home/donghan2/Stat480/hb-workspace/joindata.txt -param output=/home/donghan2/Stat480/hb-workspace/out_2 ch16-pig/src/main/pig/hw06_Q2.pig


#Exercise 3
pig -x local -param input=/home/donghan2/Stat480/hb-workspace/joindata.txt -param output=/home/donghan2/Stat480/hb-workspace/out_3 ch16-pig/src/main/pig/hw06_Q3.pig